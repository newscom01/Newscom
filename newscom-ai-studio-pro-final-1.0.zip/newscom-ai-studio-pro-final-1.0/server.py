"""NEWSCOM optional local API gateway. Python 3.10+, standard library only.
Run: NEWSCOM_AI_API_KEY=... python server.py
The upstream endpoint must support OpenAI-compatible /chat/completions.
"""
import json, os, urllib.request, urllib.error, base64, subprocess, tempfile, shutil
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parent/'www'
HOST=os.getenv('NEWSCOM_HOST','127.0.0.1')
PORT=int(os.getenv('PORT','8765'))
ALLOWED_ORIGIN=os.getenv('NEWSCOM_ALLOWED_ORIGIN','*')
API_URL=os.getenv('NEWSCOM_AI_API_URL','https://api.openai.com/v1/chat/completions')
MODEL=os.getenv('NEWSCOM_AI_MODEL','gpt-4.1-mini')
KEY=os.getenv('NEWSCOM_AI_API_KEY','')
VOICE_KEY=os.getenv('NEWSCOM_ELEVENLABS_API_KEY','')
VOICE_ID=os.getenv('NEWSCOM_ELEVENLABS_VOICE_ID','JBFqnCBsd6RMkjVDRZzb')
IMAGE_KEY=os.getenv('NEWSCOM_IMAGE_API_KEY',KEY)
IMAGE_MODEL=os.getenv('NEWSCOM_IMAGE_MODEL','gpt-image-1')
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def cors(self):
  self.send_header('Access-Control-Allow-Origin',ALLOWED_ORIGIN);self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS');self.send_header('Access-Control-Allow-Headers','Content-Type')
 def do_OPTIONS(self):
  self.send_response(204);self.cors();self.end_headers()
 def send_json(self,status,data):
  body=json.dumps(data).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.cors();self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def send_binary(self,status,body,mime):
  self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.cors();self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def do_GET(self):
  if urlsplit(self.path).path=='/api/status':return self.send_json(200,{'configured':bool(KEY),'model':MODEL,'voice_configured':bool(VOICE_KEY),'image_configured':bool(IMAGE_KEY),'mp4_available':bool(shutil.which('ffmpeg'))})
  return super().do_GET()
 def do_POST(self):
  if urlsplit(self.path).path=='/api/image':
   if not IMAGE_KEY:return self.send_json(503,{'error':'Image generation API key not configured'})
   try:
    length=int(self.headers.get('Content-Length','0'))
    if not 1<=length<=5000:return self.send_json(413,{'error':'Invalid request size'})
    data=json.loads(self.rfile.read(length));prompt=str(data.get('prompt','')).strip()
    if not 3<=len(prompt)<=1000:return self.send_json(400,{'error':'Prompt must be 3–1000 characters'})
    payload={'model':IMAGE_MODEL,'prompt':prompt,'size':'1536x1024','n':1}
    req=urllib.request.Request('https://api.openai.com/v1/images/generations',json.dumps(payload).encode(),headers={'Authorization':'Bearer '+IMAGE_KEY,'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(req,timeout=180) as response:result=json.load(response)
    encoded=result['data'][0].get('b64_json')
    if not encoded:return self.send_json(502,{'error':'Image provider did not return base64 image data'})
    if len(encoded)>12000000:return self.send_json(502,{'error':'Image exceeds allowed size'})
    return self.send_json(200,{'image':'data:image/png;base64,'+encoded})
   except urllib.error.HTTPError as e:return self.send_json(502,{'error':f'Image provider returned HTTP {e.code}'})
   except Exception as e:return self.send_json(502,{'error':'Image generation failed: '+type(e).__name__})
  if urlsplit(self.path).path=='/api/mp4':
   if not shutil.which('ffmpeg'):return self.send_json(503,{'error':'FFmpeg is not installed on the server'})
   try:
    length=int(self.headers.get('Content-Length','0'))
    if not 1<=length<=60000000:return self.send_json(413,{'error':'Video must be below 60 MB'})
    with tempfile.TemporaryDirectory() as td:
     source=Path(td)/'input.webm';target=Path(td)/'output.mp4'
     with source.open('wb') as f:
      remaining=length
      while remaining:
       chunk=self.rfile.read(min(1048576,remaining))
       if not chunk:raise ValueError('Incomplete upload')
       f.write(chunk);remaining-=len(chunk)
     command=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y','-i',str(source),'-c:v','libx264','-preset','veryfast','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',str(target)]
     result=subprocess.run(command,capture_output=True,timeout=180)
     if result.returncode!=0 or not target.exists():return self.send_json(422,{'error':'Could not convert this WebM recording to MP4'})
     if target.stat().st_size>80000000:return self.send_json(413,{'error':'Output exceeds 80 MB'})
     return self.send_binary(200,target.read_bytes(),'video/mp4')
   except subprocess.TimeoutExpired:return self.send_json(504,{'error':'MP4 conversion timed out'})
   except Exception as e:return self.send_json(502,{'error':'MP4 conversion failed: '+type(e).__name__})
  if urlsplit(self.path).path=='/api/voice':
   if not VOICE_KEY:return self.send_json(503,{'error':'Voice service not configured'})
   try:
    length=int(self.headers.get('Content-Length','0'))
    if not 1<=length<=14000:return self.send_json(413,{'error':'Invalid request size'})
    data=json.loads(self.rfile.read(length));narration=str(data.get('text','')).strip()
    if not narration or len(narration)>4500:return self.send_json(400,{'error':'Narration must contain 1–4500 characters'})
    body=json.dumps({'text':narration,'model_id':'eleven_multilingual_v2'}).encode()
    url='https://api.elevenlabs.io/v1/text-to-speech/'+VOICE_ID
    req=urllib.request.Request(url,body,headers={'xi-api-key':VOICE_KEY,'Content-Type':'application/json','Accept':'audio/mpeg'},method='POST')
    with urllib.request.urlopen(req,timeout=100) as r:audio=r.read(15000001)
    if len(audio)>15000000:return self.send_json(502,{'error':'Voice response too large'})
    return self.send_binary(200,audio,'audio/mpeg')
   except urllib.error.HTTPError as e:return self.send_json(502,{'error':f'Voice provider returned HTTP {e.code}'})
   except Exception as e:return self.send_json(502,{'error':'Voice request failed: '+type(e).__name__})
  if urlsplit(self.path).path!='/api/script':return self.send_json(404,{'error':'Not found'})
  if not KEY:return self.send_json(503,{'error':'AI service not configured on server'})
  try:
   length=int(self.headers.get('Content-Length','0'))
   if length<1 or length>12000:return self.send_json(413,{'error':'Invalid request size'})
   data=json.loads(self.rfile.read(length));topic=str(data.get('topic','')).strip()[:250];style=str(data.get('style','Educational'))[:50];duration=str(data.get('duration','5 minutes'))[:30]
   if not topic:return self.send_json(400,{'error':'Topic is required'})
   payload={'model':MODEL,'messages':[{'role':'system','content':'Write a useful original video narration script with clear sections and scene cues. Do not invent factual citations. Mark uncertain claims for verification.'},{'role':'user','content':f'Topic: {topic}\nStyle: {style}\nTarget duration: {duration}. Write the complete script with opening hook, clear sections, and closing.'}],'temperature':0.7}
   req=urllib.request.Request(API_URL,json.dumps(payload).encode(),headers={'Authorization':'Bearer '+KEY,'Content-Type':'application/json'},method='POST')
   with urllib.request.urlopen(req,timeout=100) as response:result=json.load(response)
   script=result['choices'][0]['message']['content']
   return self.send_json(200,{'script':script})
  except urllib.error.HTTPError as e:return self.send_json(502,{'error':f'AI provider returned HTTP {e.code}'})
  except Exception as e:return self.send_json(502,{'error':'AI request failed: '+type(e).__name__})
if __name__=='__main__':
 print(f'NEWSCOM v1.0 running at http://{HOST}:{PORT} | AI configured: {bool(KEY)}')
 ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
