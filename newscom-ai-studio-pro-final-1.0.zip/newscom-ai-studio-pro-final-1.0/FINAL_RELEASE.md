# NEWSCOM AI Studio Pro 1.0 — Final Release Candidate

This package consolidates the v0.1–v0.7 prototype line into one Android/Web source release candidate.

## Implemented workflow
- Local/template script drafting plus optional server-side AI script generation.
- Script-to-storyboard and editable scene list.
- Browser speech preview plus optional server-side AI narration MP3.
- Optional server-side AI scene-image generation.
- Scene timeline with reorder/edit/duplicate/delete and duration controls.
- Microphone narration recording where browser permissions allow it.
- WebM export in compatible browsers, with optional audio track.
- Server-side WebM→MP4 conversion when FFmpeg is installed.
- Local project save/import/export and PWA assets.
- Capacitor configuration for Android packaging.
- Configurable HTTPS backend URL for mobile builds; provider keys remain server-side.

## Run locally
Python 3.10+:
`python server.py`
Then open http://127.0.0.1:8765

## Android build
Install Node.js, JDK/Android Studio/Android SDK, then from this folder:
`npm install`
`npx cap add android` (first build only)
`npx cap sync android`
`npx cap open android`
Build an APK/AAB in Android Studio.

## Production deployment
Host server.py behind HTTPS/reverse proxy, configure environment variables from .env.example, set NEWSCOM_ALLOWED_ORIGIN to the production frontend origin, and set the app's Backend Base URL to that HTTPS endpoint.

## Honest scope
This is a release candidate/source application, not a signed Play Store binary. Live provider integrations require your own accounts/API credentials and may incur charges. A true CapCut-class frame-accurate multitrack editor and InVideo-class generative video engine require substantially more native/media infrastructure than this prototype and are not claimed as completed here.
