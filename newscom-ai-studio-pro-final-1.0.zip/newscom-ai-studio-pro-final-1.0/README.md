# NEWSCOM AI Studio Pro v0.7 — Android/web source

## New in v0.7
- **Backend connection settings** on Dashboard: save an HTTPS API server URL for a deployed Android/web app, or leave blank for the same-origin local Python server. No provider secrets are stored in the app.
- **Visual storyboard timeline** showing scene order, proportional durations and total running time. Tap a segment to preview its frame.
- **Duplicate scene** control for faster editing.
- **Mobile layout improvements** for scene controls and horizontal timeline.
- Retains optional AI scripts, ElevenLabs narration, AI scene images, WebM video export, optional FFmpeg MP4 conversion and project import/export from v0.6.

## Run locally
Python 3.10+: `python server.py`, then visit `http://127.0.0.1:8765`. For optional MP4 conversion install FFmpeg. AI provider keys belong **only** on the server; see `server.py` and the v0.6 configuration notes.

## Android build (requires Node.js, Android SDK and Android Studio)
1. `npm install`
2. `npx cap add android` (first time only)
3. `npx cap sync android`
4. `npx cap open android`
5. In Android Studio build a debug APK and test it on a device.

An Android phone **cannot reach the computer backend using its own localhost**. Host the Python backend securely on HTTPS and enter that address on Dashboard. The backend needs correctly configured CORS for the app origin; a cross-origin browser call may fail without it. The current server is **not production hardened** (no auth, billing, quotas, or abuse prevention), so do **not** expose it publicly as-is.

## Known limitations
This package is source code, **not a compiled APK**. Browser recording capabilities and WebM exports vary by device. MP4 requires the server and FFmpeg. Voice cloning, generative video clips, professional multitrack editing and user accounts are not implemented. The scene timeline is a storyboard, not a frame-accurate video editor. AI functions require your own API access and may incur charges. The project has not been verified on a physical Android device.
