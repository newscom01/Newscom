# NEWSCOM AI Studio Pro — v0.2 prototype

## Launch
Open `index.html` in a modern browser. For PWA installation, microphone access and offline caching, **serve over HTTPS or localhost**. On a laptop: `python -m http.server 8000` then open `http://localhost:8000`.

## Working features
- Template-assisted script drafts (not connected to a generative AI model)
- Convert script sections to an editable scene storyboard
- Create, edit, reorder and remove scenes; optional uploaded background images
- Preview scenes and export **silent WebM** video (browser dependent)
- Preview narration with device/browser text-to-speech
- Record microphone narration as a **separate audio file** (permission + secure context required)
- Save project locally; export/import project JSON
- PWA manifest and offline cache when served from HTTPS/localhost (installation varies by browser)

## Limitations
**Not an Android APK.** No paid AI providers connected, no real text-to-video, voice cloning, cloud synchronization, audio/video muxing, MP4 export, or full professional multitrack timeline. Browser storage is device-local. Long exports can be slow. Do not put third-party API keys into client-side JavaScript.

## Next engineering steps
Create a secure backend for licensed AI providers, implement server-side audio/video muxing and MP4 rendering, add accounts/cloud projects, then package/test/sign an Android build.
